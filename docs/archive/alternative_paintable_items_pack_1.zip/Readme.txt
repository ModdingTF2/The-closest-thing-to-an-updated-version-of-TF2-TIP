1) Choose Non-VPK or VPK

For VPK:

Just drag which of the fixes you want to: 
"\Steam\steamapps\common\Team Fortress 2\tf\custom" (not inside my custom files)

If you want all five, just put all three in custom.

------------------------------------------------------------

For Non-VPK

1)Open one of the fixes you want (the folder)

Move the "materials" to:

"\Steam\steamapps\common\Team Fortress 2\tf\custom\my custom files" (Now, INSIDE the my custom files folder)

If you want all five, just merge three times the materials folder. It's not going to replace, unless you have
any skin for those 5 hats.