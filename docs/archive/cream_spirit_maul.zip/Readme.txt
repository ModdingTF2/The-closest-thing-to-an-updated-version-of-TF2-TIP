1) Choose Non-VPK or VPK

For VPK:

Just drag which of the variations you want to: 
"\Steam\steamapps\common\Team Fortress 2\tf\custom" (not inside my custom files)

------------------------------------------------------------

For Non-VPK

1)Open one of the variations you want (the folder)

Move the "materials" to:

"\Steam\steamapps\common\Team Fortress 2\tf\custom\my custom files" (Now, INSIDE the my custom files folder)