1) Choose one of the versions.

2) Just drag "materials" to:

steamapps\common\Team Fortress 2\tf\custom\my custom files (or any other name you have put here)

---

If "vpk", drag the "Variation 1 - Red Team Stripe Fix.vpk" or "Variation 2 - Red Team - TF2 Logo Fix.vpk" to:

steamapps\common\Team Fortress 2\tf\custom\ *Put on this folder, do not put inside my custom files*