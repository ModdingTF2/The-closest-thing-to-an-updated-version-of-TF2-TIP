1) Choose Non-VPK or VPK

For VPK:

Just drag "Fixed Stereoscopic Shades" to: 
"\Steam\steamapps\common\Team Fortress 2\tf\custom" (not inside my custom files)

------------------------------------------------------------

For Non-VPK

Move the "materials" to:

"\Steam\steamapps\common\Team Fortress 2\tf\custom\my custom files" (Now, INSIDE the my custom files folder)